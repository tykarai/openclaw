import Foundation

enum TalkModePhase: String {
    case idle
    case listening
    case thinking
    case speaking
}
